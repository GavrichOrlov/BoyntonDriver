import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController, NavController } from '@ionic/angular';
@Component({
  selector: 'app-documentmanagement',
  templateUrl: './documentmanagement.page.html',
  styleUrls: ['./documentmanagement.page.scss'],
})
export class DocumentmanagementPage implements OnInit {
  public documents = [{
    'name': 'Identification Card',
    'icon': 'person',
    'url':'/home'
  }, {
      'name': 'Driving License',
      'icon': 'person',
      'url': '/drivinglicense'
    }]
  constructor(public route:Router, public navCtrl: NavController) { }

  ngOnInit() {
  }
  gotoPage(item: any) {
    this.route.navigate([item])

  }
  goToBack(){
    this.navCtrl.back();
  }
}
